# Open-source notices

## Three.js

Copyright © 2010-2026 three.js authors. Distributed under the MIT License.

https://github.com/mrdoob/three.js/blob/dev/LICENSE

## OpenStreetMap

Map data © OpenStreetMap contributors. OpenStreetMap data is available under the Open Database License.

https://www.openstreetmap.org/copyright

This project keeps the required OpenStreetMap attribution visible in the experience.
