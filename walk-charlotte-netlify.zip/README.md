# Walk Charlotte

A first-person browser experience that streams real Charlotte roads, paths, parks, and building footprints from OpenStreetMap.

## Controls

- Desktop: click the scene, use the mouse to look, and use W/A/S/D to walk. Hold Shift to move faster.
- Mobile: use the left joystick to walk and drag on the right side to look.

## Deploy

1. Unzip the ready package.
2. Open the existing `isaacbuzadzhi/minecrafttype` repository on GitHub.
3. Choose **Add file → Upload files**.
4. Drag every extracted file and folder into the upload page and commit the changes.
5. Netlify installs the dependencies and runs `npm run build` automatically. Your existing Netlify project and domain stay connected.

You do **not** have to delete `game.zip`, `world.zip`, `site.zip`, or the previous Minecraft files. The new `netlify.toml` ignores them. You may delete those old files later simply to clean up the repository.

Make sure the new `netlify.toml`, `package.json`, `package-lock.json`, `index.html`, `src` folder, and `public` folder all reach GitHub.

Map data © OpenStreetMap contributors, available under the Open Database License.
