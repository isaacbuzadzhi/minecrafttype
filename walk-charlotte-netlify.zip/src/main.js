import * as THREE from 'three'
import './styles.css'

const canvas = document.querySelector('#world')
const loading = document.querySelector('#loading')
const loadingMessage = document.querySelector('#loadingMessage')
const progressBar = document.querySelector('#progressBar')
const enterButton = document.querySelector('#enterButton')
const coordinates = document.querySelector('#coordinates')
const streamStatus = document.querySelector('#streamStatus')

const ORIGIN = { lat: 35.22712, lon: -80.84312 }
const METERS_LAT = 110540
const METERS_LON = 111320 * Math.cos(ORIGIN.lat * Math.PI / 180)
const CELL_METERS = 650
const VIEW_RADIUS = 1
const PLAYER_HEIGHT = 1.72
const PLAYER_RADIUS = 0.42
const BASE_SPEED = 7.5

const scene = new THREE.Scene()
scene.background = new THREE.Color('#9fc3d3')
scene.fog = new THREE.FogExp2('#b7cbd2', 0.0007)

const camera = new THREE.PerspectiveCamera(72, innerWidth / innerHeight, 0.08, 5000)
camera.rotation.order = 'YXZ'
camera.position.set(0, PLAYER_HEIGHT, 0)

const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' })
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.75))
renderer.setSize(innerWidth, innerHeight)
renderer.outputColorSpace = THREE.SRGBColorSpace
renderer.shadowMap.enabled = true
renderer.shadowMap.type = THREE.PCFSoftShadowMap

scene.add(new THREE.HemisphereLight('#d9eff8', '#65715d', 2.25))
const sun = new THREE.DirectionalLight('#fff3d4', 2.6)
sun.position.set(-240, 420, 180)
sun.castShadow = true
sun.shadow.mapSize.set(2048, 2048)
sun.shadow.camera.left = -500
sun.shadow.camera.right = 500
sun.shadow.camera.top = 500
sun.shadow.camera.bottom = -500
sun.shadow.camera.far = 1000
scene.add(sun)

const ground = new THREE.Mesh(
  new THREE.PlaneGeometry(60000, 60000),
  new THREE.MeshStandardMaterial({ color: '#8fa47f', roughness: 1 })
)
ground.rotation.x = -Math.PI / 2
ground.receiveShadow = true
scene.add(ground)

const grid = new THREE.GridHelper(60000, 1200, '#83947a', '#83947a')
grid.position.y = 0.012
grid.material.opacity = 0.1
grid.material.transparent = true
scene.add(grid)

const city = new THREE.Group()
scene.add(city)

const roadMaterials = {
  motorway: new THREE.MeshStandardMaterial({ color: '#8a8179', roughness: .95 }),
  primary: new THREE.MeshStandardMaterial({ color: '#777675', roughness: .95 }),
  street: new THREE.MeshStandardMaterial({ color: '#6f7474', roughness: .98 }),
  path: new THREE.MeshStandardMaterial({ color: '#b8ae98', roughness: 1 })
}
const buildingPalette = ['#c7b7a3', '#aa9a88', '#c9c4b8', '#9caaa6', '#bdafa6', '#8d9999']
const buildingMaterials = buildingPalette.map(color => new THREE.MeshStandardMaterial({ color, roughness: .82, metalness: .03 }))
const roofMaterial = new THREE.MeshStandardMaterial({ color: '#767873', roughness: .9 })

const cells = new Map()
const collisionBoxes = []
const loadQueue = []
let activeLoads = 0
let loadedCount = 0
let currentCell = ''
let started = false
let yaw = 0
let pitch = -0.04
let lastTime = performance.now()

const keys = new Set()
const mobileMove = { x: 0, y: 0 }

function worldFromGeo(lat, lon) {
  return new THREE.Vector2((lon - ORIGIN.lon) * METERS_LON, -(lat - ORIGIN.lat) * METERS_LAT)
}

function geoFromWorld(x, z) {
  return { lat: ORIGIN.lat - z / METERS_LAT, lon: ORIGIN.lon + x / METERS_LON }
}

function cellCoords(x, z) {
  return { x: Math.floor((x + CELL_METERS / 2) / CELL_METERS), z: Math.floor((z + CELL_METERS / 2) / CELL_METERS) }
}

function cellBounds(cx, cz) {
  const west = ORIGIN.lon + ((cx - .5) * CELL_METERS) / METERS_LON
  const east = ORIGIN.lon + ((cx + .5) * CELL_METERS) / METERS_LON
  const north = ORIGIN.lat - ((cz - .5) * CELL_METERS) / METERS_LAT
  const south = ORIGIN.lat - ((cz + .5) * CELL_METERS) / METERS_LAT
  return { south: Math.min(south, north), west: Math.min(west, east), north: Math.max(south, north), east: Math.max(west, east) }
}

function requestNearbyCells(force = false) {
  const c = cellCoords(camera.position.x, camera.position.z)
  const key = `${c.x}:${c.z}`
  if (!force && key === currentCell) return
  currentCell = key
  queueCell(c.x, c.z)
  for (let dz = -VIEW_RADIUS; dz <= VIEW_RADIUS; dz++) {
    for (let dx = -VIEW_RADIUS; dx <= VIEW_RADIUS; dx++) {
      if (dx !== 0 || dz !== 0) queueCell(c.x + dx, c.z + dz)
    }
  }
  pumpQueue()
}

function queueCell(cx, cz) {
  const key = `${cx}:${cz}`
  if (cells.has(key)) return
  cells.set(key, { status: 'queued' })
  loadQueue.push({ cx, cz, key })
}

async function pumpQueue() {
  while (activeLoads < 2 && loadQueue.length) {
    const job = loadQueue.shift()
    activeLoads++
    loadCell(job).finally(() => { activeLoads--; pumpQueue(); updateStreamStatus() })
  }
  updateStreamStatus()
}

function updateStreamStatus() {
  const busy = activeLoads + loadQueue.length
  streamStatus.textContent = busy ? `Mapping nearby Charlotte blocks · ${busy} remaining` : 'Nearby Charlotte blocks ready'
  streamStatus.classList.toggle('visible', busy > 0)
}

async function loadCell({ cx, cz, key }) {
  const bounds = cellBounds(cx, cz)
  const bbox = `${bounds.south},${bounds.west},${bounds.north},${bounds.east}`
  const query = `[out:json][timeout:25];(way[building](${bbox});way[highway](${bbox});way[leisure=park](${bbox});way[landuse=grass](${bbox}););out tags geom;`
  let data
  if (cx === 0 && cz === 0) {
    try {
      const response = await fetch('/data/uptown.json')
      if (!response.ok) throw new Error(`Bundled map ${response.status}`)
      data = await response.json()
    } catch (error) {
      console.warn('Bundled Uptown map failed', error)
    }
  }
  const endpoints = ['https://overpass-api.de/api/interpreter', 'https://overpass.kumi.systems/api/interpreter']
  for (const endpoint of endpoints) {
    if (data) break
    try {
      const response = await fetch(endpoint, { method: 'POST', body: new URLSearchParams({ data: query }) })
      if (!response.ok) throw new Error(`Map service ${response.status}`)
      data = await response.json()
      break
    } catch (error) {
      console.warn('Map endpoint failed', endpoint, error)
    }
  }
  if (!data) {
    cells.set(key, { status: 'failed' })
    if (!loadedCount) showLoadProblem()
    return
  }
  const group = new THREE.Group()
  group.userData.cellKey = key
  for (const element of data.elements || []) {
    if (!element.geometry?.length) continue
    if (element.tags?.building) addBuilding(element, group)
    else if (element.tags?.highway) addRoad(element, group)
    else addGreenSpace(element, group)
  }
  city.add(group)
  cells.set(key, { status: 'loaded', group })
  loadedCount++
  if (loadedCount === 1) {
    progressBar.style.width = '100%'
    loadingMessage.textContent = 'Uptown is ready to explore.'
    enterButton.disabled = false
    enterButton.textContent = 'Enter Charlotte'
  } else {
    progressBar.style.width = `${Math.min(95, 28 + loadedCount * 8)}%`
  }
}

function polygonPoints(element) {
  const pts = element.geometry.map(p => worldFromGeo(p.lat, p.lon))
  if (pts.length > 2 && pts[0].distanceTo(pts.at(-1)) < .2) pts.pop()
  return pts
}

function addBuilding(element, group) {
  const pts = polygonPoints(element)
  if (pts.length < 3) return
  const shape = new THREE.Shape()
  shape.moveTo(pts[0].x, -pts[0].y)
  for (let i = 1; i < pts.length; i++) shape.lineTo(pts[i].x, -pts[i].y)
  const levels = Number.parseFloat(element.tags['building:levels'])
  const taggedHeight = Number.parseFloat(String(element.tags.height || '').replace('m', ''))
  const height = Number.isFinite(taggedHeight) ? taggedHeight : Number.isFinite(levels) ? levels * 3.25 : 8 + (hash(element.id) % 7) * 2.4
  const geometry = new THREE.ExtrudeGeometry(shape, { depth: Math.min(height, 250), bevelEnabled: false })
  geometry.rotateX(-Math.PI / 2)
  const mesh = new THREE.Mesh(geometry, buildingMaterials[hash(element.id) % buildingMaterials.length])
  mesh.castShadow = height < 80
  mesh.receiveShadow = true
  group.add(mesh)

  const box = new THREE.Box3().setFromObject(mesh)
  box.min.x -= PLAYER_RADIUS
  box.max.x += PLAYER_RADIUS
  box.min.z -= PLAYER_RADIUS
  box.max.z += PLAYER_RADIUS
  collisionBoxes.push({ box, cellKey: group.userData.cellKey })

  if (height > 25) {
    const size = new THREE.Vector3()
    const center = new THREE.Vector3()
    box.getSize(size); box.getCenter(center)
    const roof = new THREE.Mesh(new THREE.BoxGeometry(Math.max(1, size.x - 1.2), .45, Math.max(1, size.z - 1.2)), roofMaterial)
    roof.position.set(center.x, height + .23, center.z)
    group.add(roof)
  }
}

function roadWidth(type) {
  if (['motorway', 'trunk'].includes(type)) return 13
  if (['primary', 'secondary'].includes(type)) return 9
  if (['tertiary', 'residential', 'service', 'unclassified'].includes(type)) return 6
  return 2.2
}

function addRoad(element, group) {
  const pts = element.geometry.map(p => worldFromGeo(p.lat, p.lon))
  const type = element.tags.highway
  const width = roadWidth(type)
  const material = ['footway', 'path', 'pedestrian', 'cycleway', 'steps'].includes(type) ? roadMaterials.path : ['motorway', 'trunk'].includes(type) ? roadMaterials.motorway : ['primary', 'secondary'].includes(type) ? roadMaterials.primary : roadMaterials.street
  for (let i = 1; i < pts.length; i++) {
    const a = pts[i - 1], b = pts[i]
    const dx = b.x - a.x, dz = b.y - a.y
    const length = Math.hypot(dx, dz)
    if (length < .4) continue
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(width, .09, length + .4), material)
    mesh.position.set((a.x + b.x) / 2, .055, (a.y + b.y) / 2)
    mesh.rotation.y = Math.atan2(dx, dz)
    mesh.receiveShadow = true
    group.add(mesh)
  }
}

function addGreenSpace(element, group) {
  const pts = polygonPoints(element)
  if (pts.length < 3) return
  const shape = new THREE.Shape()
  shape.moveTo(pts[0].x, -pts[0].y)
  for (let i = 1; i < pts.length; i++) shape.lineTo(pts[i].x, -pts[i].y)
  const geometry = new THREE.ShapeGeometry(shape)
  geometry.rotateX(-Math.PI / 2)
  const mesh = new THREE.Mesh(geometry, new THREE.MeshStandardMaterial({ color: '#78946e', roughness: 1 }))
  mesh.position.y = .018
  group.add(mesh)
}

function hash(value) {
  let x = Number(value) || 1
  x = ((x >> 16) ^ x) * 0x45d9f3b
  x = ((x >> 16) ^ x) * 0x45d9f3b
  return Math.abs((x >> 16) ^ x)
}

function showLoadProblem() {
  loadingMessage.textContent = 'The live map service is busy. Retry in a moment.'
  enterButton.disabled = false
  enterButton.textContent = 'Retry map'
  enterButton.dataset.retry = 'true'
}

function enterWorld() {
  if (enterButton.dataset.retry) {
    enterButton.disabled = true
    enterButton.textContent = 'Retrying…'
    for (const [key, value] of cells) if (value.status === 'failed') cells.delete(key)
    requestNearbyCells(true)
    return
  }
  started = true
  loading.classList.add('hidden')
  if (matchMedia('(pointer: fine)').matches) canvas.requestPointerLock?.()
}

enterButton.addEventListener('click', enterWorld)
canvas.addEventListener('click', () => { if (started && matchMedia('(pointer: fine)').matches) canvas.requestPointerLock?.() })
document.querySelector('#hideHelp').addEventListener('click', () => document.querySelector('#helpCard').remove())

document.addEventListener('keydown', e => keys.add(e.code))
document.addEventListener('keyup', e => keys.delete(e.code))
document.addEventListener('mousemove', e => {
  if (document.pointerLockElement !== canvas) return
  yaw -= e.movementX * .0022
  pitch = THREE.MathUtils.clamp(pitch - e.movementY * .002, -1.42, 1.42)
})

function setupJoystick() {
  const joystick = document.querySelector('#joystick')
  const stick = document.querySelector('#stick')
  let activeId = null
  function update(e) {
    const rect = joystick.getBoundingClientRect()
    const x = e.clientX - (rect.left + rect.width / 2)
    const y = e.clientY - (rect.top + rect.height / 2)
    const max = 40
    const length = Math.hypot(x, y)
    const scale = length > max ? max / length : 1
    const sx = x * scale, sy = y * scale
    stick.style.transform = `translate(${sx}px, ${sy}px)`
    mobileMove.x = sx / max
    mobileMove.y = sy / max
  }
  joystick.addEventListener('pointerdown', e => { activeId = e.pointerId; joystick.setPointerCapture(activeId); update(e) })
  joystick.addEventListener('pointermove', e => { if (e.pointerId === activeId) update(e) })
  function release(e) { if (e.pointerId !== activeId) return; activeId = null; mobileMove.x = 0; mobileMove.y = 0; stick.style.transform = '' }
  joystick.addEventListener('pointerup', release)
  joystick.addEventListener('pointercancel', release)

  const lookZone = document.querySelector('#lookZone')
  let lookId = null, lastX = 0, lastY = 0
  lookZone.addEventListener('pointerdown', e => { lookId = e.pointerId; lastX = e.clientX; lastY = e.clientY; lookZone.setPointerCapture(lookId) })
  lookZone.addEventListener('pointermove', e => {
    if (e.pointerId !== lookId) return
    yaw -= (e.clientX - lastX) * .007
    pitch = THREE.MathUtils.clamp(pitch - (e.clientY - lastY) * .006, -1.3, 1.3)
    lastX = e.clientX; lastY = e.clientY
  })
  const endLook = e => { if (e.pointerId === lookId) lookId = null }
  lookZone.addEventListener('pointerup', endLook)
  lookZone.addEventListener('pointercancel', endLook)
}
setupJoystick()

function collides(x, z) {
  const point = new THREE.Vector3(x, 1, z)
  for (const { box } of collisionBoxes) if (box.containsPoint(point)) return true
  return false
}

function movePlayer(dt) {
  if (!started) return
  let side = (keys.has('KeyD') ? 1 : 0) - (keys.has('KeyA') ? 1 : 0) + mobileMove.x
  let forward = (keys.has('KeyW') ? 1 : 0) - (keys.has('KeyS') ? 1 : 0) - mobileMove.y
  const length = Math.hypot(side, forward)
  if (length > 1) { side /= length; forward /= length }
  const speed = BASE_SPEED * (keys.has('ShiftLeft') || keys.has('ShiftRight') ? 1.9 : 1)
  const dx = (Math.cos(yaw) * side - Math.sin(yaw) * forward) * speed * dt
  const dz = (-Math.sin(yaw) * side - Math.cos(yaw) * forward) * speed * dt
  const nx = camera.position.x + dx
  if (!collides(nx, camera.position.z)) camera.position.x = nx
  const nz = camera.position.z + dz
  if (!collides(camera.position.x, nz)) camera.position.z = nz
  camera.rotation.set(pitch, yaw, 0)
}

function updateCoordinates() {
  const geo = geoFromWorld(camera.position.x, camera.position.z)
  coordinates.textContent = `${geo.lat.toFixed(5)}, ${geo.lon.toFixed(5)}`
}

function animate(now) {
  const dt = Math.min(.05, (now - lastTime) / 1000)
  lastTime = now
  movePlayer(dt)
  requestNearbyCells()
  updateCoordinates()
  renderer.render(scene, camera)
  requestAnimationFrame(animate)
}

addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight
  camera.updateProjectionMatrix()
  renderer.setSize(innerWidth, innerHeight)
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.75))
})

progressBar.style.width = '18%'
requestNearbyCells(true)
requestAnimationFrame(animate)
